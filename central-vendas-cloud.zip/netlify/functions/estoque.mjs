import { getDatabase } from "@netlify/database";
import { checkAuth, json } from "./_shared/auth.mjs";

export default async (req) => {
  const db = getDatabase();

  if (req.method === "GET") {
    const rows = await db.sql`SELECT id, nome, quantidade, preco FROM estoque ORDER BY nome`;
    return json(rows);
  }

  if (req.method === "POST") {
    const role = await checkAuth(db, req, "loja");
    if (!role) return json({ error: "Apenas o perfil loja pode adicionar itens ao estoque." }, 403);

    const { nome, quantidade, preco } = await req.json().catch(() => ({}));
    if (!nome || quantidade == null || preco == null || quantidade < 0 || preco < 0) {
      return json({ error: "Preencha nome, quantidade e preço corretamente." }, 400);
    }

    const [item] = await db.sql`
      INSERT INTO estoque (nome, quantidade, preco)
      VALUES (${nome}, ${quantidade}, ${preco})
      RETURNING id, nome, quantidade, preco
    `;
    return json(item, 201);
  }

  if (req.method === "DELETE") {
    const role = await checkAuth(db, req, "admin");
    if (!role) return json({ error: "Apenas o perfil admin pode remover itens do estoque." }, 403);

    const id = new URL(req.url).searchParams.get("id");
    if (!id) return json({ error: "Informe o item a remover." }, 400);

    await db.sql`DELETE FROM estoque WHERE id = ${id}`;
    return json({ ok: true });
  }

  return json({ error: "Método não permitido." }, 405);
};

export const config = { path: "/api/estoque" };
