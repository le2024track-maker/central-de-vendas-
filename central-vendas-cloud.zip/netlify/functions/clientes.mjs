import { getDatabase } from "@netlify/database";
import { checkAuth, json } from "./_shared/auth.mjs";

export default async (req) => {
  const db = getDatabase();

  if (req.method === "GET") {
    const rows = await db.sql`SELECT id, nome, telefone FROM clientes ORDER BY nome`;
    return json(rows);
  }

  if (req.method === "POST") {
    const role = await checkAuth(db, req);
    if (!role) return json({ error: "Faça login para adicionar clientes." }, 403);

    const { nome, telefone } = await req.json().catch(() => ({}));
    if (!nome) return json({ error: "Informe o nome do cliente." }, 400);

    const [cliente] = await db.sql`
      INSERT INTO clientes (nome, telefone)
      VALUES (${nome}, ${telefone || null})
      RETURNING id, nome, telefone
    `;
    return json(cliente, 201);
  }

  if (req.method === "DELETE") {
    const role = await checkAuth(db, req, "admin");
    if (!role) return json({ error: "Apenas o perfil admin pode remover clientes." }, 403);

    const id = new URL(req.url).searchParams.get("id");
    if (!id) return json({ error: "Informe o cliente a remover." }, 400);

    await db.sql`DELETE FROM clientes WHERE id = ${id}`;
    return json({ ok: true });
  }

  return json({ error: "Método não permitido." }, 405);
};

export const config = { path: "/api/clientes" };
