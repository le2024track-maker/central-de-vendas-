// Confere o token enviado pelo site (header Authorization: Bearer <token>)
// e devolve o "role" (admin/loja) de quem está logado, ou null se inválido.
// Se requiredRole for passado, só aceita aquele perfil específico.
export async function checkAuth(db, req, requiredRole) {
  const authHeader = req.headers.get("authorization") || "";
  const token = authHeader.replace(/^Bearer\s+/i, "").trim();
  if (!token) return null;

  const rows = await db.sql`
    SELECT role FROM sessoes WHERE token = ${token} AND expira_em > now() LIMIT 1
  `;
  if (rows.length === 0) return null;

  const { role } = rows[0];
  if (requiredRole && role !== requiredRole) return null;
  return role;
}

export function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });
}
