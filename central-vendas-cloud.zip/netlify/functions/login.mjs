import { getDatabase } from "@netlify/database";
import crypto from "node:crypto";
import { json } from "./_shared/auth.mjs";

export default async (req) => {
  if (req.method !== "POST") return json({ error: "Método não permitido." }, 405);

  const { role, usuario, senha } = await req.json().catch(() => ({}));
  if (!role || !usuario || !senha) return json({ error: "Preencha usuário e senha." }, 400);
  if (role !== "admin" && role !== "loja") return json({ error: "Perfil inválido." }, 400);

  const db = getDatabase();
  const rows = await db.sql`
    SELECT id FROM usuarios
    WHERE role = ${role} AND usuario = ${usuario} AND senha_hash = crypt(${senha}, senha_hash)
    LIMIT 1
  `;
  if (rows.length === 0) {
    return json({ error: "Usuário, senha ou perfil incorretos." }, 401);
  }

  const token = crypto.randomUUID();
  const expira = new Date(Date.now() + 1000 * 60 * 60 * 12); // sessão dura 12h
  await db.sql`
    INSERT INTO sessoes (token, role, expira_em) VALUES (${token}, ${role}, ${expira.toISOString()})
  `;

  return json({ token, role });
};

export const config = { path: "/api/login" };
