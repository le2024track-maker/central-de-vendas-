import { getDatabase } from "@netlify/database";
import { checkAuth, json } from "./_shared/auth.mjs";

export default async (req) => {
  if (req.method !== "PATCH") return json({ error: "Método não permitido." }, 405);

  const db = getDatabase();
  const role = await checkAuth(db, req, "admin");
  if (!role) return json({ error: "Apenas o perfil admin pode alterar usuários." }, 403);

  const { targetRole, usuario, senha } = await req.json().catch(() => ({}));
  if (!targetRole || !usuario || !senha) return json({ error: "Preencha usuário e senha." }, 400);
  if (targetRole !== "admin" && targetRole !== "loja") return json({ error: "Perfil inválido." }, 400);

  await db.sql`
    UPDATE usuarios
    SET usuario = ${usuario}, senha_hash = crypt(${senha}, gen_salt('bf'))
    WHERE role = ${targetRole}
  `;

  return json({ ok: true });
};

export const config = { path: "/api/usuarios" };
