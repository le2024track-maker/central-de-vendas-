-- Cria a extensão usada para guardar senhas com hash (nunca em texto puro)
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS usuarios (
  id serial PRIMARY KEY,
  role text UNIQUE NOT NULL CHECK (role IN ('admin', 'loja')),
  usuario text NOT NULL,
  senha_hash text NOT NULL
);

CREATE TABLE IF NOT EXISTS estoque (
  id serial PRIMARY KEY,
  nome text NOT NULL,
  quantidade integer NOT NULL DEFAULT 0,
  preco numeric(10,2) NOT NULL DEFAULT 0,
  criado_em timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS clientes (
  id serial PRIMARY KEY,
  nome text NOT NULL,
  telefone text,
  criado_em timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS sessoes (
  token text PRIMARY KEY,
  role text NOT NULL,
  expira_em timestamptz NOT NULL
);

-- Logins iniciais (troque as senhas depois de entrar, no painel Usuários)
INSERT INTO usuarios (role, usuario, senha_hash)
VALUES
  ('admin', 'admin', crypt('admin123', gen_salt('bf'))),
  ('loja',  'loja',  crypt('loja123',  gen_salt('bf')))
ON CONFLICT (role) DO NOTHING;
